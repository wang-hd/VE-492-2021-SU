"""
Run python autograder.py
"""


def add(a, b):
    return a+b
